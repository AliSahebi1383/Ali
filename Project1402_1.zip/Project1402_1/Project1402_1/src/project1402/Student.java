package project1402;

import java.util.ArrayList;

public class Student {
    private String Name;
    private String Family;
    private int Age;
    private String Address;
    private int code;
    private String field;
    private String NameClass;
    private String gender;

    public Student(String Name, String Family, int code, String field,String gender) {
        this.Name = Name;
        this.Family = Family;
        this.code = code;
        this.field = field;
        this.gender=gender;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    
    

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getFamily() {
        return Family;
    }

    public void setFamily(String family) {
        Family = family;
    }

    public int getAge() {
        return Age;
    }

    public void setAge(int age) {
        Age = age;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

   
    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getNameClass() {
        return NameClass;
    }

    public void setNameClass(String nameClass) {
        NameClass = nameClass;
    }
}
